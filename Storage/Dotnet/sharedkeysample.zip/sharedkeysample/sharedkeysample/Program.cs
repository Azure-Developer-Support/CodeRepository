﻿
//DISCLAIMER

//The sample scripts are not supported under any Microsoft standard support program or service.
//The sample scripts are provided AS IS without warranty of any kind.Microsoft further disclaims all implied warranties including, without limitation, 
//any implied warranties of merchantability or of fitness for a particular purpose.The entire risk arising out of the use or performance of the sample 
//scripts and documentation remains with you. In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of 
//the scripts be liable for any damages whatsoever (including without limitation, damages for loss of business profits, business interruption, loss of business 
//information, or other pecuniary loss) arising out of the use of or inability to use the sample scripts or documentation, even if Microsoft has been advised of
//the possibility of such damages.


using System;
using System.Globalization;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;


namespace sharedkeysample
{
    class Program
    {
        static string StorageAccountName = "mystorageaccount";
        static string StorageAccountKey = "*************************";

        static void Main(string[] args)
        {
            ListContainersAsyncREST(StorageAccountName, StorageAccountKey, CancellationToken.None).GetAwaiter().GetResult();
      
            Console.WriteLine("Press any key to continue.");
            Console.ReadLine();

        }
        private static async Task ListContainersAsyncREST(string storageAccountName, string storageAccountKey, CancellationToken cancellationToken)
        {

           // System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11;
            //   String uri = string.Format("http://{0}.blob.core.windows.net/mycontainer/myblob.txt", storageAccountName); 
            String uri = string.Format("https://{0}.blob.core.windows.net/mycontainer/myblobname.txt", storageAccountName); 
            Byte[] requestPayload = null;

         
            using (var httpRequestMessage = new HttpRequestMessage(HttpMethod.Get, uri)
            { Content = (requestPayload == null) ? null : new ByteArrayContent(requestPayload) })
            {

             
                DateTime now = DateTime.UtcNow;
                httpRequestMessage.Headers.Add("x-ms-date", now.ToString("R", CultureInfo.InvariantCulture));
                //  httpRequestMessage.Headers.Add("x-ms-version", "2017-04-17");

                httpRequestMessage.Headers.Add("x-ms-version", "2017-07-29");

                httpRequestMessage.Headers.Authorization = AzureStorageAuthenticationHelper.GetAuthorizationHeader(
                   storageAccountName, storageAccountKey, now, httpRequestMessage);
                Console.WriteLine("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                Console.WriteLine("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                Console.WriteLine(AzureStorageAuthenticationHelper.GetAuthorizationHeader(storageAccountName, storageAccountKey, now, httpRequestMessage).ToString());
                Console.WriteLine("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                Console.WriteLine("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                Console.WriteLine(httpRequestMessage);


                using (HttpResponseMessage httpResponseMessage = await new HttpClient().SendAsync(httpRequestMessage, cancellationToken))
                {
                   
                    if (httpResponseMessage.StatusCode == HttpStatusCode.OK)
                    {
                        String xmlString = await httpResponseMessage.Content.ReadAsStringAsync();
                      

                        Console.WriteLine(xmlString);
                    }
                }
            }
        }

        private static string GenerateSharedKey(string stringToSign, string key, string account)
        {
            string signature;
            var unicodeKey = Convert.FromBase64String(key);
            using (var hmacSha256 = new HMACSHA256(unicodeKey))
            {
                var dataToHmac = Encoding.UTF8.GetBytes(stringToSign);
                signature = Convert.ToBase64String(hmacSha256.ComputeHash(dataToHmac));
            }
            return string.Format(CultureInfo.InvariantCulture, "{0} {1}:{2}", "SharedKey", account, signature);
        }


    }
}
