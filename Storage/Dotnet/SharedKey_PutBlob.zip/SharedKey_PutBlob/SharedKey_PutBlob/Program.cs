﻿//DISCLAIMER

//The sample scripts are not supported under any Microsoft standard support program or service.
//The sample scripts are provided AS IS without warranty of any kind.Microsoft further disclaims all implied warranties including, without limitation, 
//any implied warranties of merchantability or of fitness for a particular purpose.The entire risk arising out of the use or performance of the sample 
//scripts and documentation remains with you. In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of 
//the scripts be liable for any damages whatsoever (including without limitation, damages for loss of business profits, business interruption, loss of business 
//information, or other pecuniary loss) arising out of the use of or inability to use the sample scripts or documentation, even if Microsoft has been advised of
//the possibility of such damages.


using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace SharedKey_PutBlob
{
    class Program
    {
        static void Main(string[] args)
        {
            string containerName = "mycontainer";
            string blobName = "myfilename.txt";

            PutBlob(containerName,blobName);
            Console.ReadLine();
        }

        public static void PutBlob(String containerName, String blobName)
        {
            String storageBlobEndpoint = "https://mystorageaccount.blob.core.windows.net/";
            String StorageAccount = "mystorageaccount";

            String requestMethod = "PUT";

            String urlPath = String.Format("{0}/{1}", containerName, blobName);

            String storageServiceVersion = "2018-03-28";
            String dateInRfc1123Format = DateTime.UtcNow.ToString("R", CultureInfo.InvariantCulture);

            String content = "My sample text file content";
            UTF8Encoding utf8Encoding = new UTF8Encoding();
            Byte[] blobContent = utf8Encoding.GetBytes(content);
            Int32 blobLength = blobContent.Length;

            const String blobType = "BlockBlob";

            String canonicalizedHeaders = String.Format(
                    "x-ms-blob-type:{2}\nx-ms-date:{0}\nx-ms-version:{1}",
                    dateInRfc1123Format,
                    storageServiceVersion, blobType);
            String canonicalizedResource = String.Format("/{0}/{1}", StorageAccount, urlPath);
            String stringToSign = String.Format(
                    "{0}\n\n\n{3}\n\n\n\n\n\n\n\n\n{1}\n{2}",
                    requestMethod,
                    canonicalizedHeaders,
                    canonicalizedResource,
                    blobLength
                    );
            Console.WriteLine("string to sign:" + stringToSign + ":ended");
            String authorizationHeader = CreateAuthorizationHeader(stringToSign, StorageAccount);

            Uri uri = new Uri(storageBlobEndpoint + urlPath);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            request.Method = requestMethod;
            request.Headers.Add("x-ms-blob-type", blobType);

            request.Headers.Add("x-ms-date", dateInRfc1123Format);

            request.Headers.Add("x-ms-version", storageServiceVersion);

            request.Headers.Add("Authorization", authorizationHeader);

            request.ContentLength = blobLength;

            using (Stream requestStream = request.GetRequestStream())
            {
                requestStream.Write(blobContent, 0, blobLength);
            }
        }


        public static String CreateAuthorizationHeader(String canonicalizedString, string StorageAccount)
        {
            String storageAccountKey = "***************************";
            String signature = String.Empty;

            using (HMACSHA256 hmacSha256 = new HMACSHA256(Convert.FromBase64String(storageAccountKey)))
            {
                Byte[] dataToHmac = System.Text.Encoding.UTF8.GetBytes(canonicalizedString);
                signature = Convert.ToBase64String(hmacSha256.ComputeHash(dataToHmac));
            }

            String authorizationHeader = String.Format(
                CultureInfo.InvariantCulture,
                "{0} {1}:{2}",
                "SharedKey",
                StorageAccount,
                signature
            );

            return authorizationHeader;
        }

    }
}
